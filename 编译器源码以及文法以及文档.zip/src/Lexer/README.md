#
分别定义了
Date_Deal.py
存放运行时需要的数据

DFA.py
NFA的确定化实现

FA.py
有限状态机类实现

Helper_Func.py
辅助函数实现

Lexer.py
词法分析实现

Main.py
可独立运行和输出tokens结果，
这里使用的是绝对路径所以需要修改输入输出的文件路径

Minimize_DFA.py
最小化DFA实现

TransformMap.py
状态转换表类实现

#
测试输入代码在根目录下的input/lex_input
测试输出结果在根目录下的out_put/lex_outpur

#
注意：
目前还没有添加struct、union、switch的识别