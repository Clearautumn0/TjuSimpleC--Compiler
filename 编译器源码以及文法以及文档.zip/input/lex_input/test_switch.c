void main() {
    int x = 2;
    int y = 3;
    int =2;
    switch (x) {
        case 1: {
            y = 10;
            break;
        }
        case 2: {
            y = 20;
            func(y);
            break;
        }
        default: {
            return 0;
        }
    }
}