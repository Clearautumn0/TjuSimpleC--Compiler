void main(){
    int =1;
    return 2;
}