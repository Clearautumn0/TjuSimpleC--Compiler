void main(){
    const int a = 10, b = 5;
    return b;
}