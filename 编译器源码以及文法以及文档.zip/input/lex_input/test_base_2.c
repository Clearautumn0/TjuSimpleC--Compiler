int b = 3;

void main(){
    int a = 4;
    return a + b;
}