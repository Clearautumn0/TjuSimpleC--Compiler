struct my_struct1 {

  int value;

  void my_func(struct a b, int my_int, struct my_struct ccc) {}

struct my_struct me;
} s1, s2;

struct my_struct2 {

  int value;

  void my_func(struct a b, int my_int, struct my_struct ccc) {}

struct my_struct me;
} s;

struct my_struct3 {

  int value;

  void my_func(struct a b, int my_int, struct my_struct ccc) {}

  struct my_struct me;

union my_union mu;
};